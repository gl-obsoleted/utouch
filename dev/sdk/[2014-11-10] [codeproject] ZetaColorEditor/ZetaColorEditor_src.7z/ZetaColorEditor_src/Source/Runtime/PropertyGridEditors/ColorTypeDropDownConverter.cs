﻿namespace ZetaColorEditor.Runtime.PropertyGridEditors
{
	using System.Drawing;

	public class ColorTypeDropDownConverter : 
		ColorConverter
	{
	}
}